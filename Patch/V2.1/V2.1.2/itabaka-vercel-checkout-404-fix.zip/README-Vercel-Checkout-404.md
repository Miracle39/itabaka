# Itabaka — Fix Vercel checkout/invoice 404

## Perubahan
Konfigurasi Vite memasukkan `checkout.html` dan `invoice.html` ke multi-page build. Kedua file HTML tersebut ada di repository, tetapi sebelumnya tidak tercantum dalam `build.rollupOptions.input`.

## Cara memasang
1. Ekstrak ZIP patch.
2. Ganti `vite.config.js` di root project dengan file dari ZIP.
3. Di terminal VS Code, jalankan:
   ```bash
   npm run build
   ```
4. Periksa folder `dist`. Pastikan ada `checkout.html` dan `invoice.html`.
5. Commit dan push perubahan ke branch yang digunakan Vercel untuk Production. Setelah itu tunggu deployment selesai.
6. Coba kembali alur keranjang → checkout → invoice di URL deployment.

Tidak ada perubahan database, SQL, atau proses pembayaran. Patch ini juga tidak melakukan commit/push otomatis.
