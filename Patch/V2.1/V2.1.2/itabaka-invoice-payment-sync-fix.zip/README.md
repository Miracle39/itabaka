# Itabaka — Invoice payment amount sync fix

## Pemasangan
Ganti file project `src/invoice.js` dengan file `src/invoice.js` di dalam ZIP.

## Perubahan
- Jika respons RPC tidak berisi `total_amount`, total dihitung dari subtotal detail barang.
- `Bayar Sekarang` dihitung mengikuti rencana pembayaran: FULL = total pesanan; DP = persentase DP yang tersimpan di checkout/admin settings.
- `Sisa Pembayaran` dihitung ulang sebagai `Total Pesanan - Dibayar (terverifikasi)`.
- Pembayaran yang baru diunggah buktinya tidak otomatis dianggap terverifikasi; nominal yang dibayar tetap berasal dari catatan admin.
- Tidak ada perubahan SQL atau skema database.
